package com.codegym.a0222i1.repository;

import com.codegym.a0222i1.model.ClassRoom;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IClassroomRepository extends JpaRepository<ClassRoom, Integer> {
}
